function sayHello() {
    alert("Hi there! Thanks for visiting my site 🌟");
  }
  